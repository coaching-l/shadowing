import { useEffect, useMemo, useRef, useState } from "react";
import {
  Play,
  Pause,
  SkipBack,
  SkipForward,
  RotateCcw,
  RotateCw,
  Mic,
  Square,
  Download,
  Repeat2,
} from "lucide-react";
import {
  formatTime,
  mergeAudio,
  NO_GAP,
  timeline,
  validRange,
  wavBlob,
} from "./core";
import type { Clip, Span } from "./core";
import type { Lesson, Recording } from "./storage";
import { download, encodeMP3, zipMP3 } from "./export";
import Timeline from "./Timeline";
import RecordingFeedback from "./RecordingFeedback";
import ImportedAudioTranscript from "./ImportedAudioTranscript";
import SecondsInput from "./SecondsInput";
import { usePracticeRecording } from "./use-practice-recording";
type Props = {
  lesson: Lesson;
  clips: Clip[];
  update: (patch: Partial<Lesson>) => void;
  error: (message: string) => void;
  recording: Recording | undefined;
  setRecording: (r: Recording | undefined) => void;
  aiBlocked: boolean;
  onAIBusyChange: (busy: boolean) => void;
  onPrepareAI: () => void;
  onCaptureChange: (busy: boolean) => void;
};
export default function Practice({
  lesson,
  clips,
  update,
  error,
  recording,
  setRecording,
  aiBlocked,
  onAIBusyChange,
  onPrepareAI,
  onCaptureChange,
}: Props) {
  const { gap, mode, a, b, repeat, repeatGap } = lesson;
  const rate = lesson.rate ?? 1,
    loop = lesson.loop ?? false;
  const setRate = (rate: number) => update({ rate }),
    setLoop = (loop: boolean) => update({ loop });
  const merged = useMemo<
    | { samples: Float32Array; rate: number; spans: Span[] }
    | { error: string }
    | null
  >(() => {
    try {
      // Imported audio is already one continuous clip. Keep its PCM in place
      // rather than allocating another full-file copy before ASR on phones.
      if (lesson.voice === "imported" && clips.length === 1) {
        const clip = clips[0];
        if (clip.samples.length > clip.rate * 60 * 20)
          throw Error(
            "端末のメモリーを保護するため、音声は20分までです。教材を分けてください。",
          );
        return {
          samples: clip.samples,
          rate: clip.rate,
          spans: timeline(clips, NO_GAP),
        };
      }
      return clips.length
        ? mergeAudio(clips, mode === "repeat" ? gap : NO_GAP)
        : null;
    } catch (e) {
      return { error: String(e) };
    }
  }, [clips, gap, mode, lesson.voice]);
  const data = merged && "samples" in merged ? merged : null;
  const audio = useRef<HTMLAudioElement>(null),
    recordAudio = useRef<HTMLAudioElement>(null);
  const timer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined),
    frame = useRef(0),
    playRequest = useRef(0),
    counter = useRef(1),
    boundary = useRef<{
      a: number;
      b: number;
      loop: boolean;
      after?: () => void;
    } | null>(null);
  const [playing, setPlaying] = useState(false),
    [time, setTime] = useState(0),
    [iteration, setIteration] = useState(1),
    [waiting, setWaiting] = useState(false),
    [exporting, setExporting] = useState(false),
    [exports, setExports] = useState<{ name: string; blob: Blob }[]>([]),
    [group, setGroup] = useState(10),
    [modelVolume, setModelVolume] = useState(1),
    [ownVolume, setOwnVolume] = useState(1);
  const priorData = useRef(data),
    gapWaiting = useRef(false);
  const duration = data ? data.samples.length / data.rate : 0;
  const capture = usePracticeRecording({
    playModel: (target, ended, failed) =>
      startRange(
        target.a,
        target.b,
        false,
        ended,
        target.a,
        target.rate,
        failed,
      ),
    stopModel: () => stop(),
    onRecording: setRecording,
    onError: error,
  });
  const recordingRange = validRange(a, b, duration)
    ? { a, b }
    : { a: 0, b: duration };
  useEffect(() => {
    onCaptureChange(capture.busy);
  }, [capture.busy, onCaptureChange]);
  useEffect(() => () => onCaptureChange(false), [onCaptureChange]);
  const settings = useRef({ repeat, repeatGap });
  settings.current = { repeat, repeatGap };
  function stop(except?: HTMLAudioElement) {
    playRequest.current++;
    gapWaiting.current = false;
    clearTimeout(timer.current);
    cancelAnimationFrame(frame.current);
    if (audio.current !== except) audio.current?.pause();
    if (recordAudio.current !== except) recordAudio.current?.pause();
    boundary.current = null;
    setPlaying(false);
    setWaiting(false);
  }
  async function safePlay(failed?: (message: string) => void) {
    const request = ++playRequest.current;
    try {
      await audio.current!.play();
      if (request === playRequest.current) setPlaying(true);
    } catch (e) {
      // Seeking, pausing or reaching B can interrupt an older play() promise.
      if (request !== playRequest.current) return;
      stop();
      (failed ?? error)(
        "再生を開始できませんでした。再生ボタンを押してください。 " + String(e),
      );
    }
  }
  function startRange(
    start: number,
    end: number,
    looping: boolean,
    after?: () => void,
    position = start,
    playbackRate = rate,
    failed?: (message: string) => void,
  ) {
    stop();
    if (!validRange(start, end, duration)) {
      (failed ?? error)("0 ≦ A < B ≦ 音声の長さにしてください。");
      return;
    }
    counter.current = 1;
    setIteration(1);
    boundary.current = { a: start, b: end, loop: looping, after };
    audio.current!.playbackRate = playbackRate;
    audio.current!.currentTime = position;
    setTime(position);
    void safePlay(failed);
  }
  useEffect(() => {
    if (!data) return;
    const el = audio.current!;
    const url = URL.createObjectURL(wavBlob(data.samples, data.rate));
    el.src = url;
    return () => {
      capture.cancel();
      stop();
      el.removeAttribute("src");
      el.load();
      URL.revokeObjectURL(url);
    };
  }, [data]);
  useEffect(() => {
    if (priorData.current === data) return;
    priorData.current = data;
    stop();
    setExports([]);
    setTime(0);
    if (a !== 0 || b !== 0 || loop) update({ a: 0, b: 0, loop: false });
    setRecording(undefined);
  }, [data]);
  useEffect(() => {
    audio.current!.playbackRate = rate;
    audio.current!.preservesPitch = true;
  }, [rate, data]);
  useEffect(() => {
    audio.current!.volume = modelVolume;
  }, [modelVolume]);
  useEffect(() => {
    if (recordAudio.current) recordAudio.current.volume = ownVolume;
  }, [ownVolume, recording]);
  useEffect(() => {
    if (!recording) return;
    const el = recordAudio.current!;
    const url = URL.createObjectURL(recording.blob);
    el.src = url;
    return () => {
      el.pause();
      el.removeAttribute("src");
      URL.revokeObjectURL(url);
    };
  }, [recording]);
  useEffect(() => {
    const onHide = () => {
      if (document.hidden) stop();
    };
    document.addEventListener("visibilitychange", onHide);
    return () => document.removeEventListener("visibilitychange", onHide);
  }, []);
  useEffect(() => {
    stop();
  }, [a, b, loop, repeat, repeatGap]);
  useEffect(() => {
    const onOtherPlay = (e: Event) => {
      if (e.target !== audio.current && e.target instanceof HTMLAudioElement) {
        capture.cancel();
        stop(e.target);
      }
    };
    document.addEventListener("play", onOtherPlay, true);
    return () => document.removeEventListener("play", onOtherPlay, true);
  }, []);
  function tick() {
    cancelAnimationFrame(frame.current);
    if (gapWaiting.current) return;
    const el = audio.current;
    if (!el) return;
    setTime(el.currentTime);
    const target = boundary.current;
    if (target && (el.currentTime >= target.b - 0.015 || el.ended)) {
      playRequest.current++;
      el.pause();
      el.currentTime = target.b;
      setTime(target.b);
      cancelAnimationFrame(frame.current);
      if (
        target.loop &&
        (settings.current.repeat === 0 ||
          counter.current < settings.current.repeat)
      ) {
        gapWaiting.current = true;
        setWaiting(true);
        timer.current = setTimeout(() => {
          gapWaiting.current = false;
          counter.current++;
          setIteration(counter.current);
          setWaiting(false);
          el.currentTime = target.a;
          void safePlay();
        }, settings.current.repeatGap * 1000);
      } else {
        const after = target.after;
        boundary.current = null;
        setPlaying(false);
        setWaiting(false);
        after?.();
      }
      return;
    }
    if (!el.paused) frame.current = requestAnimationFrame(tick);
  }
  function toggle() {
    if (playing || waiting) {
      stop();
      return;
    }
    if (loop) {
      const current = audio.current!.currentTime;
      startRange(
        a,
        b,
        true,
        undefined,
        current >= a && current < b - 0.02 ? current : a,
      );
      return;
    }
    const start =
      audio.current!.currentTime >= duration - 0.02
        ? 0
        : audio.current!.currentTime;
    startRange(start, duration, false);
  }
  function skip(seconds: number) {
    if (!data || capture.busy) return;
    if (loop && !validRange(a, b, duration)) {
      error("0 ≦ A < B ≦ 音声の長さにしてください。");
      return;
    }
    const el = audio.current!;
    const start = loop ? a : 0,
      end = loop ? b : duration,
      next = Math.max(start, Math.min(end, el.currentTime + seconds)),
      resume = playing || waiting;
    stop();
    el.playbackRate = rate;
    el.currentTime = next;
    setTime(next);
    if (resume && (next < end || loop)) {
      boundary.current = { a: start, b: end, loop };
      void safePlay();
    }
  }
  async function output(kind: "plain" | "gaps" | "ab" | "parts") {
    if (!data || exporting) return;
    setExporting(true);
    stop();
    setExports([]);
    try {
      const safeTitle = (lesson.title || "lesson").replace(
        /[\\/:*?"<>|]/g,
        "_",
      );
      const groups =
        kind === "parts"
          ? Array.from({ length: Math.ceil(clips.length / group) }, (_, i) =>
              clips.slice(i * group, (i + 1) * group),
            )
          : [clips];
      const files = [];
      for (let i = 0; i < groups.length; i++) {
        const merged = mergeAudio(groups[i], kind === "gaps" ? gap : NO_GAP);
        const samples =
          kind === "ab"
            ? data.samples.slice(
                Math.round(a * data.rate),
                Math.round(b * data.rate),
              )
            : merged.samples;
        if (kind === "ab" && !validRange(a, b, duration))
          throw Error("A–B区間を設定してください。");
        const blob = await encodeMP3(samples, merged.rate);
        files.push({
          name: `${safeTitle}-${kind}-${String(i + 1).padStart(2, "0")}.mp3`,
          blob,
        });
      }
      setExports(files);
    } catch (e) {
      error(String(e));
    } finally {
      setExporting(false);
    }
  }
  const active =
    data?.spans.findIndex((s) => time >= s.start && time < s.end) ?? -1;
  return (
    <section className="card practice">
      <div className="section-heading">
        <h2>04 練習する</h2>
        <span className="tag">{clips.length}文の音声</span>
      </div>
      <p className="muted">
        生成音声、または持ち込み音声で練習できます。再生速度と練習の無音は、音声の再生成なしで変更できます。
      </p>
      {merged && "error" in merged && <p role="alert">{merged.error}</p>}
      <div className="segmented">
        <button
          aria-pressed={mode === "shadow"}
          disabled={capture.busy}
          onClick={() => update({ mode: "shadow" })}
        >
          シャドーイング
        </button>
        <button
          aria-pressed={mode === "repeat"}
          disabled={capture.busy}
          onClick={() => update({ mode: "repeat" })}
        >
          リピーティング
        </button>
      </div>
      {mode === "repeat" && (
        <div className="inset">
          <label>
            文間の無音
            <select
              value={gap.mode}
              disabled={capture.busy}
              onChange={(e) =>
                update({
                  gap: { ...gap, mode: e.target.value as typeof gap.mode },
                })
              }
            >
              <option value="none">なし</option>
              <option value="fixed">固定秒数</option>
              <option value="auto">文の長さに応じて自動</option>
            </select>
          </label>
          {gap.mode === "fixed" && (
            <label>
              無音（秒）
              <SecondsInput
                value={gap.seconds}
                disabled={capture.busy}
                onChange={(seconds) => update({ gap: { ...gap, seconds } })}
              />
            </label>
          )}
          {gap.mode === "auto" && (
            <>
              <p className="small">
                無音 = 実際の文の発話時間 × 1。下限と上限で調整します。
              </p>
              <div className="row">
                <label>
                  下限（秒）
                  <SecondsInput
                    max={gap.max}
                    value={gap.min}
                    disabled={capture.busy}
                    onChange={(min) => update({ gap: { ...gap, min } })}
                  />
                </label>
                <label>
                  上限（秒）
                  <SecondsInput
                    min={gap.min}
                    value={gap.max}
                    disabled={capture.busy}
                    onChange={(max) => update({ gap: { ...gap, max } })}
                  />
                </label>
              </div>
            </>
          )}
          <p className="small">
            無音設定・モードを変えると時刻を再計算し、A–B区間と一時録音を解除します。
          </p>
        </div>
      )}
      <audio
        ref={audio}
        onPlay={() => {
          cancelAnimationFrame(frame.current);
          frame.current = requestAnimationFrame(tick);
        }}
        onTimeUpdate={() => {
          if (
            audio.current &&
            !audio.current.paused &&
            boundary.current &&
            audio.current.currentTime >= boundary.current.b - 0.015
          )
            tick();
        }}
        onEnded={() => {
          if (boundary.current) tick();
          else setPlaying(false);
        }}
      />
      <div className="player">
        <div className="time">
          <span>{formatTime(time)}</span>
          <span>{formatTime(duration)}</span>
        </div>
        <Timeline
          samples={data?.samples ?? null}
          sampleRate={data?.rate ?? 24000}
          duration={duration}
          time={time}
          a={a}
          b={b}
          disabled={!data || capture.busy}
          onAdjustStart={() => stop()}
          onRangeChange={(range) => {
            stop();
            update({ ...range, loop: true });
          }}
          onSeek={(next) => {
            stop();
            audio.current!.currentTime = next;
            setTime(next);
          }}
        />
        <div className="transport">
          <button
            className="skip-seconds"
            aria-label="5秒戻る"
            disabled={!data || capture.busy}
            onClick={() => skip(-5)}
          >
            <RotateCcw size={22} />
            <span>5秒</span>
          </button>
          <button
            className="play-button"
            disabled={!data || capture.busy}
            onClick={toggle}
          >
            {playing || waiting ? <Pause /> : <Play />}
            {waiting ? "無音中" : playing ? "一時停止" : "再生"}
          </button>
          <button
            className="skip-seconds"
            aria-label="5秒進む"
            disabled={!data || capture.busy}
            onClick={() => skip(5)}
          >
            <RotateCw size={22} />
            <span>5秒</span>
          </button>
        </div>
        <div className="sentence-transport">
          <button
            aria-label="前の文"
            className="small-button"
            disabled={!data || capture.busy}
            onClick={() => {
              const idx = Math.max(0, active - 1);
              startRange(data!.spans[idx].start, duration, false);
            }}
          >
            <SkipBack size={16} /> 前の文
          </button>
          <button
            aria-label="次の文"
            className="small-button"
            disabled={!data || capture.busy}
            onClick={() => {
              const idx = Math.min(data!.spans.length - 1, active + 1);
              startRange(data!.spans[idx].start, duration, false);
            }}
          >
            次の文 <SkipForward size={16} />
          </button>
        </div>
        <div className="speed-section">
          <div className="speed-label">
            <label htmlFor="playback-speed">再生速度（高さを維持）</label>
            <output htmlFor="playback-speed">{rate.toFixed(2)}×</output>
          </div>
          <input
            id="playback-speed"
            disabled={capture.busy}
            type="range"
            min="0.5"
            max="2"
            step="0.05"
            value={rate}
            onChange={(e) => setRate(+e.target.value)}
          />
          <div className="speed-scale">
            <span>0.5×（ゆっくり）</span>
            <button
              className="text-button"
              disabled={capture.busy}
              onClick={() => setRate(1)}
            >
              1.0×に戻す
            </button>
            <span>2.0×（速い）</span>
          </div>
        </div>
      </div>
      <div className="inset">
        <h3>
          <Repeat2 size={18} /> A–B 区間リピート
        </h3>
        <details className="range-numbers">
          <summary>時刻を数字で調整</summary>
          <div className="row">
            <label>
              開始 A（秒）
              <input
                aria-label="開始 A（秒）"
                disabled={capture.busy}
                type="number"
                min="0"
                max={duration}
                step="0.01"
                value={a}
                onChange={(e) => update({ a: +e.target.value })}
              />
            </label>
            <label>
              終了 B（秒）
              <input
                aria-label="終了 B（秒）"
                disabled={capture.busy}
                type="number"
                min="0"
                max={duration}
                step="0.01"
                value={b}
                onChange={(e) => update({ b: +e.target.value })}
              />
            </label>
          </div>
        </details>
        <p className="small">
          {validRange(a, b, duration)
            ? `A ${formatTime(a)} → B ${formatTime(b)}`
            : a !== 0 || b !== 0
              ? "0 ≦ A < B ≦ 音声の長さにしてください。"
              : "ゲージのA・Bを動かして、繰り返したい範囲を指定してください。"}
        </p>
        <div className="row">
          <label>
            繰り返し回数
            <select
              value={repeat}
              disabled={capture.busy}
              onChange={(e) => update({ repeat: +e.target.value })}
            >
              {[1, 3, 5, 0].map((n) => (
                <option key={n} value={n}>
                  {n || "無限"}
                  {n ? "回" : ""}
                </option>
              ))}
            </select>
          </label>
          <label>
            区間の間の無音（秒）
            <SecondsInput
              value={repeatGap}
              disabled={capture.busy}
              onChange={(repeatGap) => update({ repeatGap })}
            />
          </label>
        </div>
        <div className="row">
          <label className="checkbox">
            <input
              type="checkbox"
              checked={loop}
              disabled={capture.busy || !validRange(a, b, duration)}
              onChange={(e) => setLoop(e.target.checked)}
            />
            区間リピート {loop && `· ${iteration}回目`}
          </label>
          <button
            className="text-button"
            disabled={capture.busy}
            onClick={() => {
              setLoop(false);
              update({ a: 0, b: 0 });
            }}
          >
            区間を解除
          </button>
        </div>
        <p className="small">
          ゲージのA・Bを動かすと、区間リピートがオンになります。背景に移ると、区間ずれを防ぐため再生を停止します。
        </p>
      </div>
      {data && (
        <details className="transcript">
          <summary>
            {lesson.voice === "imported"
              ? "本文を見る（音声との自動位置合わせなし）"
              : "本文を見る（文を押すとその位置から再生）"}
          </summary>
          {lesson.voice === "imported" ? (
            <p style={{ whiteSpace: "pre-wrap" }}>{lesson.text}</p>
          ) : (
            <div className="sentence-list">
              {data.spans.map((s, i) => (
                <div
                  key={i}
                  className={`sentence ${active === i ? "active" : ""}`}
                >
                  <button
                    disabled={capture.busy}
                    onClick={() => startRange(s.start, duration, false)}
                  >
                    <span className="sentence-number">
                      {String(i + 1).padStart(2, "0")} · {formatTime(s.start)}
                    </span>
                    {s.text}
                  </button>
                </div>
              ))}
            </div>
          )}
        </details>
      )}
      {lesson.voice === "imported" && data && (
        <ImportedAudioTranscript
          samples={data.samples}
          sampleRate={data.rate}
          lang={lesson.lang}
          a={a}
          b={b}
          blocked={aiBlocked || capture.busy || exporting}
          onPrepare={() => {
            stop();
            onPrepareAI();
          }}
          onBusyChange={onAIBusyChange}
          onApply={(text) => update({ text })}
        />
      )}
      <details>
        <summary>自分の声を録音して比較</summary>
        <p className="small">
          <strong>
            {mode === "shadow"
              ? "シャドーイング：お手本を聴きながら、少し遅れて同じ文章を話す練習です。"
              : "リピーティング：お手本を聴き終えてから、まねして話す練習です。"}
          </strong>
          <br />
          {mode === "shadow"
            ? "2秒のカウントダウン後、お手本の再生と録音を同時に開始します。最後の言葉まで話せるよう、お手本の終了から2秒後に自動停止します。"
            : "お手本を1回聴き、2秒のカウントダウン後にあなたの声を録音します。お手本の再生時間＋2秒で自動停止します。"}
        </p>
        <p className="small">
          録音する範囲：
          {validRange(a, b, duration) ? "選択したA–B区間" : "全文"}
          {data &&
            `（${formatTime(recordingRange.a)}–${formatTime(recordingRange.b)}、お手本 ${((recordingRange.b - recordingRange.a) / rate).toFixed(1)}秒）`}
          。 短い区間で練習したい場合は、先にゲージでA・Bを指定してください。
        </p>
        <p className="small">
          マイクの音声を端末内で録音します。お手本の音が入り込まないよう、イヤホンをお使いください。別の画面に移ると、練習と録音を中止します。
        </p>
        <button
          disabled={
            !data ||
            exporting ||
            capture.phase === "finishing" ||
            (!capture.busy && aiBlocked)
          }
          onClick={() => {
            if (capture.busy) capture.stop();
            else {
              error("");
              void capture.start({ ...recordingRange, mode, rate });
            }
          }}
        >
          {capture.busy ? <Square size={18} /> : <Mic size={18} />}{" "}
          {capture.phase === "finishing"
            ? "録音を処理中…"
            : capture.capturing
              ? "録音を停止"
              : capture.busy
                ? "録音の準備を中止"
                : mode === "shadow"
                  ? "お手本を再生しながら録音"
                  : "お手本を聴いてから録音"}
        </button>
        {capture.busy && (
          <p className="notice" role="status" aria-label="練習録音の状況">
            {capture.phase === "preparing"
              ? "マイクを準備しています。録音の許可が表示されたら許可してください。"
              : capture.phase === "listening"
                ? "まず、お手本を聴いてください。まだ録音していません。"
                : capture.phase === "countdown"
                  ? `録音開始まで ${capture.countdown}…`
                  : capture.phase === "finishing"
                    ? "録音データを準備しています…"
                    : capture.phase === "tail"
                      ? "お手本が終わりました。最後の言葉まで話してください。2秒後に録音を止めます。"
                      : `${mode === "shadow" ? "録音中：お手本を少し遅れて追いかけて話してください。" : "録音中：あなたの番です。お手本をまねして話してください。"} ${formatTime(capture.elapsed)}`}
          </p>
        )}
        <audio ref={recordAudio} />
        {recording && (
          <>
            <p className="small">録音の対応区間：{recording.label}</p>
            {recording.mode && (
              <p className="small">
                {recording.mode === "shadow"
                  ? "シャドーイング"
                  : "リピーティング"}
                の録音です。お手本と聴き比べて、発音やリズムを確認しましょう。
              </p>
            )}
            <div className="row">
              <button
                disabled={capture.busy}
                onClick={() => {
                  stop();
                  recordAudio.current!.currentTime = 0;
                  void recordAudio
                    .current!.play()
                    .catch((e) => error(String(e)));
                }}
              >
                録音を再生
              </button>
              <button
                disabled={capture.busy}
                onClick={() =>
                  startRange(
                    recording.a,
                    recording.b,
                    false,
                    () => {
                      recordAudio.current!.currentTime = 0;
                      void recordAudio
                        .current!.play()
                        .catch((e) => error(String(e)));
                    },
                    recording.a,
                    recording.rate ?? rate,
                  )
                }
              >
                お手本 → 自分の声
              </button>
              <button disabled={capture.busy} onClick={() => stop()}>
                比較を停止
              </button>
            </div>
            <RecordingFeedback
              recording={recording}
              lang={lesson.lang}
              reference={
                lesson.voice === "imported"
                  ? ""
                  : data?.spans
                      .filter(
                        (span) =>
                          span.end > recording.a && span.start < recording.b,
                      )
                      .map((span) => span.text)
                      .join(lesson.lang === "en" ? " " : "") || ""
              }
              partial={
                !!data?.spans.some(
                  (span) =>
                    (span.start < recording.a && span.end > recording.a) ||
                    (span.start < recording.b && span.end > recording.b),
                )
              }
              blocked={aiBlocked || capture.busy}
              onBusyChange={onAIBusyChange}
              onPrepare={() => {
                stop();
                onPrepareAI();
              }}
            />
          </>
        )}
        <div className="row">
          <label>
            お手本の音量
            <input
              aria-label="お手本の音量"
              type="range"
              min="0"
              max="1"
              step="0.05"
              value={modelVolume}
              onChange={(e) => setModelVolume(+e.target.value)}
            />
          </label>
          <label>
            録音の音量
            <input
              aria-label="録音の音量"
              type="range"
              min="0"
              max="1"
              step="0.05"
              value={ownVolume}
              onChange={(e) => setOwnVolume(+e.target.value)}
            />
          </label>
        </div>
      </details>
      <details>
        <summary>MP3をダウンロード</summary>
        <p className="small">
          端末内でMP3に変換します。再生速度は反映せず、生成時の等速で保存します。語尾を保つため、文の途中では分割しません。
        </p>
        <div className="button-grid">
          <button
            disabled={!data || exporting || capture.busy}
            onClick={() => void output("plain")}
          >
            <Download size={17} />
            全文・無音なし
          </button>
          <button
            disabled={!data || exporting || capture.busy}
            onClick={() => void output("gaps")}
          >
            全文・設定した無音あり
          </button>
          <button
            disabled={
              !data || exporting || capture.busy || !validRange(a, b, duration)
            }
            onClick={() => void output("ab")}
          >
            選択したA–B区間
          </button>
        </div>
        <div className="row">
          <label>
            1ファイルあたりの文数
            <input
              type="number"
              aria-describedby="mp3-split-help"
              min="1"
              max="100"
              value={group}
              onChange={(e) =>
                setGroup(Math.max(1, Math.min(100, +e.target.value)))
              }
            />
          </label>
          <button
            disabled={!data || exporting || capture.busy}
            onClick={() => void output("parts")}
          >
            文数で分割する
          </button>
        </div>
        <p id="mp3-split-help" className="small">
          「文数で分割する」を押すと、指定した文数ごとにMP3ファイルを作ります。
          例：本文が30文で「10」に設定すると、10文ずつ3つのMP3になります。
        </p>
        {exporting && <p role="status">MP3に変換中…</p>}
        {exports.map((f) => (
          <button
            className="download-link"
            key={f.name}
            onClick={() => download(f.blob, f.name)}
          >
            <Download size={16} />
            {f.name}（{Math.ceil(f.blob.size / 1024)} KB）
          </button>
        ))}
        {exports.length > 1 && (
          <button
            onClick={() => {
              void zipMP3(exports)
                .then((blob) => download(blob, "coaching-l-audio.zip"))
                .catch((e) => error(String(e)));
            }}
          >
            まとめてZIP保存
          </button>
        )}
      </details>
    </section>
  );
}
